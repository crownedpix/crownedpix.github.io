module.exports = function(grunt) {

grunt.initConfig({
    sass: {                              // Task
        dist: {                            // Target
            options: {                       // Target options
                style: 'expanded'
            },
            files: {                         // Dictionary of files
                'css/style.css': 'src/sass/*.scss',       // 'destination': 'source'
            }
        }
    },
		connect: {
        server: {
            options: {
                port: 4000,
                base: '',
                hostname: '*'
            }
        }
    },
		watch: {
            // for stylesheets, watch css and less files
            // only run less and cssmin
            files: {
              files: ['src/sass/*.scss','src/sass/partials/*.scss'],
              tasks: ['sass']
            }
        }
        //grunt task configuration will go here
    });
    //load grunt task
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-connect');
    //register grunt default task
    grunt.registerTask('default', ['connect','sass','watch']);

}
